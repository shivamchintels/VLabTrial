<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>Strings are the combination of characters that may or may not form a set of information. In simpler words it is sequence of characters. It can be your name, your address or any data that you store in it. Python programming language provides you many operations that can be performed on a string like concatenation, slicing, multiplication etc. In this lab you will learn about some of these operations.<br><br>We can access a string using indexing. In a string each character is assigned with a unique index value which starts from 0. A string can be written in both single quotes and double quotes.<br>
Example &nbsp;:&nbsp;&nbsp;'Hello World'<br>
                  "Hello World"<br>
s = "Hello World"
<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>