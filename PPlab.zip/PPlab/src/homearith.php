<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>
		Computers were brought into use to make things easier for humans. Various programming languages were developed to make programs that bring out the best from a computer. One of such is Python. In this lab you will learn to code the basic operations that can be performed by using Python on a computer.<br><br>An operator is a symbol that tells the compiler that either a mathematical or a logical manipulation has to be done. In this lab you will be studying about the Arithmetic Operations.<br><br><strong>Objective</strong><br>
1.	To understand the basics of arithmetic operations used in Python programming.<br>
2.	To learn using these operations while programming.
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>