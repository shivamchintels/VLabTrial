<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>File operations in any programming is very essential. Files are used to save and transfer data. They can be of any form, a text file or a media file. They all serve the same purpose. <br>

Here you will learn about the various methods of file operations in Python programming language.<br><br>Python provides us with various file operations. A file can be created, edited, read and even copied.In this lab you will learn about the file operations in Python by implementing them in creating and copying a file in the simulator
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>