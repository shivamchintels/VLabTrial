<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>To perform specific functions like add, subtract, power, square root, we need to write two three lines of logic to make our task or function work properly. So we have built in functions inside those modules which can straight away perform those task by passing the values to calculate.<br>

Here you will learn about some of the built-in modules used in Python programming language.<br><br>We simply have to import those built in modules present inside the program then we can easily perform those specific task after calling those functions.<br><br>Some of the modules that are used in Python are :<br>
math, datetime, decimal, operator, test, user, sets,  etc.
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>