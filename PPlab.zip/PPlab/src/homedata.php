<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>Many times there comes a need of clubbing the data together. While making a program we may require to club our data that is inter-related to each other. This data can be put together in an array.<br>
Here, you will learn about the various types od arrays in Python programming language.<br><br>Before starting with arrays you must know the concept of mutability.<br>
An object may be classified into two categories :<br>
i.	Mutable<br>
ii.	Immutable
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>