<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>Inheritance is a feature that says if you define a new class giving a reference of some other class then due to inheriting property of python your new class will inherit all attributes and behavior of the parent class.<br>
A Constructor is a special kind of method that have same name as the class in python self variable do the same. It can be used to set the values of the members of an object.<br><br><strong>Objective</strong><br>

1.	To learn about constructors and inheritance property of Python programming language.<br>
 
2.	To learn the implementation of both constructors and inheritance.
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>