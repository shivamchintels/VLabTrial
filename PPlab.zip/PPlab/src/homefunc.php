<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>
An executable program in a programming language contains multiple lines. To simplify this code, various functions are used. They can be built-in functions or user defined functions. In this lab you will learn about the built-in functions used in Python programming language.<br><br><strong>Objective</strong><br><br>
1.	To understand the basics of functions used in Python programming language.<br>

2.	To implement the 'id' and 'type' functions in a code.
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>