<!DOCTYPE html>
<html>
<head>
  <title>Identify by 'id'</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="build_idsimulator.css">
</head>
<body>
    <div  class="erp">
  <b><h1>Analysis for Built-in Functions</h1></b>
</div>

  <div class="straight">
<div class="block1">
  <div class="header1">Demonstration</div><br>
  <ul>
    <label><li> Demonstrate the working of 'id'<br>functions</li></label>
  </ul><br>&nbsp;&nbsp;
  <label>Choose first</label>
    <select class="form-control" id="option" required="required">
      <option value="">-- Select Option -- </option>
      <option value="int">Integer</option>
      <option value="float">Float</option>
      <option value="str">String</option>

    </select>


<br>
<div class="tn">
<input type="text" class="form-control input-sm" id="input_2" type="" placeholder="Enter Your Choice"><br>
<button class="btn btn-default" id="btn_1">Start</button><br>
<button class="btn btn-primary" id="btn_2">Next</button>
<button class="btn btn-primary" id="btn_3">Reset</button>
</div>
</div>
</div>

<div class="block3">
<div class="header2">Step Execute</div>
<div class="pre">

  <div class="step1" id="id" style="display:none;text-align:left;"><br><br><b>
    <p id="1">def identity(a):</p>
    <p id="2" style="padding-left:10px;">c = id(a)</p>
    <p id="3" style="padding-left:10px;">print(c)</p></b>
    </div>
</div>
</div>

<div class="block4">
<div class="header3">Result(identity)</div>
  <table>
      <tr>
        <th>Variables</th>
        <th>Values</th>
      </tr>
      <tr>
        <td id="r1" style="display:none">c :</td>
        <td id="r2_1" style="display:none">31186196</td>
        <td id="r2_2" style="display:none">31907092</td>
        <td id="r2_3" style="display:none">31587634</td>
      </tr>
      <tr>
        <td id="r4">Output :</td>
      </tr>
      <tr>
        <td id="r3"></td>
      <td id="r3_1" style="display:none">31186196</td>
      <td id="r3_2" style="display:none">31907092</td>
      <td id="r3_3" style="display:none">21677812</td>
      </tr>
  </table>
</div>


<script src="built_id.js"></script>
</body>
</html>
