<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<label>Introduction</label>
	<p><h4>Python is considered as one of the simplest language in the programming world. It provides an interface with the help of which python can be used for Software Development, GUI Development, Web Development etc. Thus, making things easier for the programmer.<br><br>With the help of our virtual lab, students get a chance to learn programming using Python language as they are provided with an interactive simulator. It is beneficial in understanding the basics of a language which simply cannot be understood by self evaluation.To make a user friendly virtual platform that provides opportunity for progressive learning and understanding the concepts of Python programming language</h4></p>
</div>
</body>
</html>