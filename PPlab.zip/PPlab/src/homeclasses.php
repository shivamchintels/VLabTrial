<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>Classes are the blueprints or we can say a group of sets of instructions that perform specific task for a object.<br>
It is used to keep related tasks together.
Objects is an instance of class which stores variables and functions that are passed from the class. An object tells about the behavior and property of a class.<br><br>There are three things that we can do with class<br><br>
<strong>1.)	Class variables:-</strong> A variable that can be shared by each and every object of the class.<br>
<strong>2.)	Instance variable:-</strong> A variable that is unique and can be used only in the instance or object in which it is called<br>
<strong>3.)	Method :-</strong> These are the functions that define inside a class.
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>