<!DOCTYPE html>
<html>
<head>
	<title>Introduction</title>
</head>
<body>
<?php include 'homepart.php'; ?>
<div class="container">
	<h2>About</h2>
	<p><h4>The role of a programming language is to act as a translator or as a medium through which our instructions can reach to the computer. We write certain codes in programming language which is passed to the computer to process.<br><br>

Sometimes we may require to get the information of the system we are working on. Such problems may be overcome with the help of a programming language. In this lab you will learn to get the system information in Python programming language.<br><br>
A computer is capable of showing us it's basic information which can be helpful in many ways. Some of them are time and date.<br><br>

There may be instances when a program is to be made where the exact time and date of execution may be required.
	<a href="lab/index.php" style="text-decoration: none;"><button class="btn btn-primary">Explore >></button></a></p></h4>
</div>
</body>
</html>